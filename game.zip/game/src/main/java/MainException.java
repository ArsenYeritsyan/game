public class MainException extends Exception{
    public MainException(String message) {
        super(message);
    }
}
